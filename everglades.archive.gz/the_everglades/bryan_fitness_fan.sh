#!/bin/bash

file_name="FitnessFans.txt"

sleep 20

sam_room_num=$(pgrep -f "sam_potter_fan.sh")

sleep 10

if [ -z $sam_room_num ];
    then
	echo -e "BRYAN: Hey Connie, could not find Sam :( . Would have loved to invite him.\n\n" >> $file_name
    else
        echo -e "BRYAN: Connie, found Sam in $sam_room_num. Have invited him for a bike ride. See in the lobby at 9am!\n\n" >> $file_name
fi

i=0
while [ $i -lt 50 ]
do
((i++))
sleep 10
done
