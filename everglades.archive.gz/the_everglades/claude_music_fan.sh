#!/bin/bash

file_name="MusicFans.txt"

if [ -f "$file_name" ]; then
	rm -f $file_name
fi

# Wait for Sam to check-in
sleep 10

if [ -z "$(pgrep -f "sam_potter_fan.sh")" ];
    then
	echo -e "CLAUDE: Good. I can play my music lound. Won't be bothering those Potter Fans!! \n" >> $file_name
fi

i=0
while [ $i -lt 50 ]
do
((i++))
sleep 10 
done
