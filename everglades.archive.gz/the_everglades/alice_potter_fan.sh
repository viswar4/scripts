#!/bin/bash

file_name="PotterFans.txt"

if [ -f "$file_name" ]; then
	rm -f $file_name
fi

# Wait for Sam to check-in
sleep 10

if [ -z "$(pgrep -f "sam_potter_fan.sh")" ];
    then
	echo -e "ALICE: Waiting for Sam\n" >> $file_name
    else
        echo -e "ALICE: Hey Sam, Loved Harry Potter. Let me know if you'd like to watch the movie. I would prefer that to going on a bike ride. !\n" >> $file_name
fi

echo -e "So many places to try out just for the Potter Fans ... \n" >> $file_name

ls ./ameneties >> $file_name

echo -e "ALICE: Love staying in $(hostname)" >> $file_name

i=0
while [ $i -lt 50 ]
do
((i++))
sleep 10 
done
