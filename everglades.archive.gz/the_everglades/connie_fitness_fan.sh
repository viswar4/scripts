#!/bin/bash

file_name="FitnessFans.txt"


if [ -f "$file_name" ]; then
	rm -f $file_name
fi

alice_room_num=$(pgrep -f "alice_potter_fan.sh")

if [ -z $alice_room_num ];
    then
	echo -e "CONNIE:  Hey Bryan, could not find Alice :(. See if you can find Sam.\n\n" >> $file_name
    else
        echo -e "CONNIE: Hey Bryan, found Alice in $alice_room_num. Have invited her for a bike ride. See if you can get Sam as well!\n\n" >> $file_name
fi

echo -e "So many places to try out just for the Fitness Fans... \n" >> $file_name
ls ./ameneties >> $file_name

if [ -d "/home/vinnar/the_everglades/Potter_Fans_Area/ameneties/Burgers_and_Fries" ] ; then
	echo "Found a burger place in Potter_Fans_Area. Yes, let's go there Bryan "  >> $file_name
else
	echo "Don't see a Potter Fans Area. Guess we should stick to our Healthy Sandwiches" >> $file_name

fi

echo -e "CONNIE: Love Staying in $(hostname) " >> $file_name

i=0
while [ $i -lt 50 ]
do
((i++))
sleep 10
done
