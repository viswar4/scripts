
# This script sets up the environment for the Potter Fans.
# Once the environment is set up, it creates a Namespace in the Overlay dir

BASE_DIR=fitness_fans
LOWER_DIR=$BASE_DIR/lower_dir
UPPER_DIR=$BASE_DIR/upper_dir
WORK_DIR=$BASE_DIR/work_dir
MERGED_DIR=$BASE_DIR/merged_dir

#Clean up the environment

if [  -d "$BASE_DIR" ]; then
    sudo rm -rf $BASE_DIR
fi

# Create the directories for the Overlay FileSystem
mkdir $BASE_DIR
mkdir $LOWER_DIR
mkdir $UPPER_DIR
mkdir $WORK_DIR
mkdir $MERGED_DIR

# Copy the required files to the Overlay FileSystem
cp connie_fitness_fan.sh $LOWER_DIR
cp bryan_fitness_fan.sh $LOWER_DIR

# Create the Overlay FileSysem with the mount command, passing the options
sudo mount -t overlay -o lowerdir=./alpine_root_dir:./Fitness_Fans_Ameneties:$LOWER_DIR,upperdir=$UPPER_DIR,workdir=$WORK_DIR none $MERGED_DIR 

cd $MERGED_DIR
mkdir old_root

sudo unshare -fpu --mount-proc /bin/bash -c "

pivot_root . old_root
mount -t proc proc proc
apk add -q bash

hostname Golden-Gate 

./connie_fitness_fan.sh &
./bryan_fitness_fan.sh &

wait
exit
"

cd ../..
sudo umount -l $MERGED_DIR
if [  -d "$BASE_DIR" ]; then
    sudo rm -rf $BASE_DIR
fi
