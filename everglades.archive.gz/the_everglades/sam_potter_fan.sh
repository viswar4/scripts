#!/bin/bash

# Wait for members to check in
sleep 20 

file_name="PotterFans.txt"

bryan_room_num=$(pgrep -f "bryan_fitness_fan.sh")

if [ -z $bryan_room_num ];

    then
	    echo -e "SAM: Nice to meet you Alice. Don't worry, I do not see Bryan, yippie! :). I believe we are safe in our bubble.\n\n" >> $file_name

    else
	echo -e "SAM: Nice to meet you Alice. Yes, I would prefer the movie to a bike ride. I see that Bryan is in $bryan_room_num. Hoping not to get invited to go biking.\n\n" >> $file_name

fi

i=0
while [ $i -lt 10 ]
do
((i++))
sleep 10
done

