
# This script sets up the environment for the Potter Fans.
# Once the environment is set up, it creates a Namespace in the Overlay dir

BASE_DIR=potter_fans
LOWER_DIR=$BASE_DIR/lower_dir
UPPER_DIR=$BASE_DIR/upper_dir
WORK_DIR=$BASE_DIR/work_dir
MERGED_DIR=$BASE_DIR/merged_dir

#Clean up the environment

if [  -d "$BASE_DIR" ]; then
    sudo rm -rf $BASE_DIR
fi

# Create the directories for the Overlay FileSystem
mkdir $BASE_DIR
mkdir $LOWER_DIR
mkdir $UPPER_DIR
mkdir $WORK_DIR
mkdir $MERGED_DIR

# Copy the required files to the Overlay FileSystem
cp alice_potter_fan.sh $LOWER_DIR
cp sam_potter_fan.sh $LOWER_DIR


# Create the Overlay FileSysem with the mount command, passing the options
sudo mount -t overlay -o lowerdir=./alpine_root_dir:./Potter_Fans_Ameneties:$LOWER_DIR,upperdir=$UPPER_DIR,workdir=$WORK_DIR none $MERGED_DIR 

cd $MERGED_DIR
mkdir old_root

# Create the Namespace and call Pivot_root to restrict the processes in this namespace
# to a specific directory
# Then launch the processes within the namespace
sudo unshare -fpu --mount-proc /bin/bash -c "

pivot_root . old_root
mount -t proc proc proc
apk add -q bash

hostname Yellowstone

./alice_potter_fan.sh &
./sam_potter_fan.sh &

wait
exit
"

cd ../..

# Clean up the Environment
sudo umount -l $MERGED_DIR

if [  -d "$BASE_DIR" ]; then
    sudo rm -rf $BASE_DIR
fi
