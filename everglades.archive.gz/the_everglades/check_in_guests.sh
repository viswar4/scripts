
./alice_potter_fan.sh &
./sam_potter_fan.sh &
./connie_fitness_fan.sh &
./bryan_fitness_fan.sh &
